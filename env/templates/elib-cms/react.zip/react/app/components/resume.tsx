import type { Content } from '~/types/cms';

type Props = {
  data: Content;
};

export function Resume({ data }: Props) {
  return (
    <main className="flex h-screen items-center justify-center">
      <h1>Resume Page</h1>
    </main>
  );
}
