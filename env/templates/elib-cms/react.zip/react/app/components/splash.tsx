import type { Content } from '~/types/cms';

type Props = {
  data: Content;
};

export function Splash({ data }: Props) {
  return (
    <main className="flex h-screen items-center justify-center">
      <h1>{data.heading.heading}</h1>
    </main>
  );
}
