import type { Section } from '~/types/cms';
import configData from './Config';

function detectError(response: Response) {
  if (!response.ok) {
    throw response;
  }
}

async function loadConfig() {
  return configData();
}

export async function fetchSection(route: string): Promise<Section> {
  const config = await configData();
  const url = `${config.proto}://${config.host}${route}`;

  const response = await fetch(url);

  detectError(response);

  const json = await response.json();
  return json as Section;
}

export function fetchHost(): string {
  return config.host;
}
