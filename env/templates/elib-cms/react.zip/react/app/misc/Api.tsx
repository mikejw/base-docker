import fs from 'fs';
import YAML from 'yaml';
import type { Section, Plugin } from '~/types/cms';

let HOST = '';
let PROTO = 'http';

function detectError(response: Response) {
  if (!response.ok) {
    throw response;
  }
}

export async function processConfig(): Promise<void> {
  return new Promise(async (resolve, reject) => {

    const filePath = process.env.NODE_ENV === 'development'
      ? '../config.yml'
      : './project/config.yml';
    const file = fs.readFileSync(filePath, 'utf8');
    const config = YAML.parse(file);

    const host = config.web_root;
    const ssl = config.plugins.some((plugin: Plugin) => {
      return plugin.name === 'SmartySSL';
    });

    HOST = host;
    PROTO = ssl ? 'https' : PROTO;
    resolve();
  });
}

export async function fetchSection(route: string): Promise<Section> {
  const url = `${PROTO}://${HOST}${route}`;

  const response = await fetch(url);

  detectError(response);

  const json = await response.json();
  return json as Section;
}

export function fetchHost(): string {
  return HOST;
}

