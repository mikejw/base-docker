import fs from 'fs';
import YAML from 'yaml';
import type { ConfigObject, Proto, Plugin } from '~/types/cms';


let config = null;

export const processConfig = async(): Promise<ConfigObject> => {
  return new Promise(async (resolve, reject) => {
    let host = '';
    let proto: Proto | undefined;

    const filePath =
      process.env.NODE_ENV === 'development'
        ? '../config.yml'
        : './project/config.yml';
    fs.readFile(filePath, 'utf8', (err, data) => {
      const config = YAML.parse(data);
      host = config.web_root;
      proto = config.plugins.some((plugin: Plugin) => {
        return plugin.name === 'SmartySSL';
      })
        ? 'https'
        : 'http';

      resolve({ host, proto });
    });
  });
}

export default async function(): ConfigObject {
  if (!config) {
    config = await processConfig();
  }
  return config;
} 
