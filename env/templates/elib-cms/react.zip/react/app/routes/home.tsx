import type { Route } from './+types/home';
import { Splash } from '~/components/splash';
import { Resume } from '~/components/resume';
import { processConfig, fetchSection } from '~/misc/Api';
import type { Section, Content } from '~/types/cms';

export function meta({}: Route.MetaArgs) {
  return [
    { title: 'New React Router App' },
    { name: 'description', content: 'Welcome to React Router!' },
  ];
}

export async function loader({ context, params }: Route.LoaderArgs) {
  const version = process.env.APP_VERSION ?? '';
  const route = params['*'] === undefined ? '/splash/' : `/${params['*']}`;

  let sectionData = {} as Section;

  try {
    const [, data] = await Promise.all([processConfig(), fetchSection(route)]);

    sectionData = {
      ...data,
    };
  } catch (err: any) {
    const error =
      err?.status === 404
        ? {
            status: 404,
            statusText: 'Not Found',
          }
        : {
            status: 500,
            statusText: 'Unknown Error',
          };

    throw new Response(null, error);
  }

  return {
    sectionData,
  };
}

export default function Home({ loaderData }: Route.ComponentProps) {
  const { content } = loaderData.sectionData;

  return (
    <>
      {content.template === 'A' && <Splash data={content} />}
      {content.template === 'B' && <Resume data={content} />}
    </>
  );
}
