interface DataItem {
  id: number;
  data_item_id: number | null;
  section_id: number | null;
  container_id: number | null;
  label: string;
  heading: string | null;
  body: string | null;
  image: string | null;
  image_width: number | null;
  image_height: number | null;
  video: string | null;
  audio: string | null;
  user_id: number;
  position: number;
  hidden: string | null;
  meta: string | null;
  stamp: string;
  data: DataItem[];
  export: boolean;
}

interface Exp {
  company: string;
  type: string;
  date: string;
  title: string;
  blurb: string;
  points: string;
}

interface Cert {
  title: string;
  value: string;
  body: string;
  stamp: string;
}

interface Edu {
  label: string;
  title: string;
  date: string;
}

export interface Content {
  template: string;
  keywords?: string;
  description?: string;

  blurb?: DataItem;
  image?: DataItem;

  heading: DataItem;

  contact?: DataItem;
  statement?: DataItem;
  skills?: DataItem;
  interests?: DataItem;
  certs?: Cert[];
  experience?: Exp[];
  education?: Edu[];
}

export interface Section {
  content: Content;
}

export interface Plugin {
  name: string;
  version: string;
  class_path?: string;
  class_name?: string;
  loader?: string;
  config?: string;
}
